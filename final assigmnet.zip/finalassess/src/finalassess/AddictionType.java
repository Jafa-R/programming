package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AddictionType {

	private JFrame frame;
	private JTextField addictionField;
	static String addictionwrite;
	private String addictions;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddictionType window = new AddictionType();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddictionType() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblWhatKindOf = new JLabel("What kind of addiction does the patient has?");
		lblWhatKindOf.setBounds(85, 61, 267, 14);
		frame.getContentPane().add(lblWhatKindOf);
		
		JLabel lblNewLabel = new JLabel("cigarettes");
		lblNewLabel.setBounds(101, 100, 60, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Hookah");
		lblNewLabel_1.setBounds(250, 100, 46, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Vape");
		lblNewLabel_2.setBounds(250, 140, 46, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("e-cigarettes");
		lblNewLabel_3.setBounds(101, 140, 76, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Pick one:");
		lblNewLabel_4.setBounds(72, 180, 69, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		addictionField = new JTextField();
		addictionField.setBounds(141, 177, 182, 20);
		frame.getContentPane().add(addictionField);
		addictionField.setColumns(10);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Addiction.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("NEXT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addictions = addictionField.getText();
				 addictionwrite = (addictions) + (";");
				 String info = AddictionType.addictionwrite;
				 try {
					 BufferedWriter File = new BufferedWriter(new FileWriter(new File("C:\\Users\\HP\\eclipse-workspace\\finalassess\\src\\finalassess\\PateintInfo.txt"), true));
					 File.write(info);
					 
					 File.close();
					
				} catch (IOException E) {
					// TODO: handle exception
				}
				 

				StickPills.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
	}
}
