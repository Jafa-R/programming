package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Temp {

	private JFrame frame;
	private JTextField bloodTypeTxt;
	private JTextField heightTxt;
	private JTextField weightTxt;
	private JTextField sugarTxt;
	private JTextField bloodPrusTxt;
	private JTextField tempTxt;
	private String bloodType, height, weight, sugarLevel, bloodPrus, temp;
	static String tpWrite;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Temp window = new Temp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Temp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblPatientInformation = new JLabel("Patient Information");
		lblPatientInformation.setBounds(153, 34, 124, 14);
		frame.getContentPane().add(lblPatientInformation);
		
		JLabel lblNewLabel = new JLabel("Temperature");
		lblNewLabel.setBounds(227, 78, 74, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblBloodPressure = new JLabel("Blood.P");
		lblBloodPressure.setBounds(227, 125, 74, 14);
		frame.getContentPane().add(lblBloodPressure);
		
		JLabel lblSugrel = new JLabel("Sugar.L");
		lblSugrel.setBounds(227, 165, 46, 14);
		frame.getContentPane().add(lblSugrel);
		
		JLabel lblBloodt = new JLabel("Blood.T");
		lblBloodt.setBounds(62, 78, 46, 14);
		frame.getContentPane().add(lblBloodt);
		
		JLabel lblHeight = new JLabel("Height");
		lblHeight.setBounds(62, 125, 46, 14);
		frame.getContentPane().add(lblHeight);
		
		JLabel lblWeight = new JLabel("Weight");
		lblWeight.setBounds(62, 165, 46, 14);
		frame.getContentPane().add(lblWeight);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("NEXT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 bloodType = bloodTypeTxt.getText();
				 height = heightTxt.getText();
				 weight = weightTxt.getText();
				 sugarLevel = sugarTxt.getText();
				 bloodPrus = bloodPrusTxt.getText();
				 temp = tempTxt.getText();
				 tpWrite = (bloodType) + (";") + (height) + (";") + (weight) + (";") + (temp) + (";") + (bloodPrus) + (";") + (sugarLevel);
				 String info = Temp.tpWrite;
				 try {
					 BufferedWriter File = new BufferedWriter(new FileWriter(new File("C:\\Users\\HP\\eclipse-workspace\\finalassess\\src\\finalassess\\PateintInfo.txt"),true));
					File.write(info);
					
					 File.close();
					
				} catch (IOException E) {
					// TODO: handle exception
				}
				
				Diseases.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		bloodTypeTxt = new JTextField();
		bloodTypeTxt.setBounds(118, 75, 86, 20);
		frame.getContentPane().add(bloodTypeTxt);
		bloodTypeTxt.setColumns(10);
		
		heightTxt = new JTextField();
		heightTxt.setBounds(118, 122, 86, 20);
		frame.getContentPane().add(heightTxt);
		heightTxt.setColumns(10);
		
		weightTxt = new JTextField();
		weightTxt.setBounds(118, 162, 86, 20);
		frame.getContentPane().add(weightTxt);
		weightTxt.setColumns(10);
		
		sugarTxt = new JTextField();
		sugarTxt.setBounds(283, 162, 86, 20);
		frame.getContentPane().add(sugarTxt);
		sugarTxt.setColumns(10);
		
		bloodPrusTxt = new JTextField();
		bloodPrusTxt.setBounds(283, 122, 86, 20);
		frame.getContentPane().add(bloodPrusTxt);
		bloodPrusTxt.setColumns(10);
		
		tempTxt = new JTextField();
		tempTxt.setBounds(311, 75, 86, 20);
		frame.getContentPane().add(tempTxt);
		tempTxt.setColumns(10);
	}

}
