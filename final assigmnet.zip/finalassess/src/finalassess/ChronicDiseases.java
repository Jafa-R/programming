package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ChronicDiseases {

	private JFrame frame;
	private JTextField allergyField;
	private JTextField diseasesField;
	private String Disease,Allergy;
	static String writeDiseases;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChronicDiseases window = new ChronicDiseases();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChronicDiseases() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblWhatDoesThe = new JLabel("What does the patient suffer from?");
		lblWhatDoesThe.setBounds(106, 61, 219, 14);
		frame.getContentPane().add(lblWhatDoesThe);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
             Diseases.main(null);
             frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNext = new JButton("NEXT");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Disease = diseasesField.getText();
				Allergy = allergyField.getText();
				 writeDiseases = (Disease) + (";") + (Allergy) + (";");
				 String info = ChronicDiseases.writeDiseases;
				 try {
					 BufferedWriter File = new BufferedWriter(new FileWriter(new File("C:\\Users\\HP\\eclipse-workspace\\finalassess\\src\\finalassess\\PateintInfo.txt"), true));
					 File.write(info);
					 File.close();
					
				} catch (Exception e2) {
					// TODO: handle exception
				}
				Addiction.main(null);
				frame.setVisible(false);
			}
		});
		btnNext.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNext);
		
		JLabel lblNewLabel = new JLabel("Athma");
		lblNewLabel.setBounds(101, 117, 46, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Diabetes");
		lblNewLabel_1.setBounds(169, 117, 58, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Any kind of Allergy:");
		lblNewLabel_2.setBounds(101, 202, 126, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Blood pressure");
		lblNewLabel_3.setBounds(247, 117, 89, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		allergyField = new JTextField();
		allergyField.setBounds(221, 196, 134, 20);
		frame.getContentPane().add(allergyField);
		allergyField.setColumns(10);
		
		JLabel lblPickOne = new JLabel("Pick one or more:");
		lblPickOne.setBounds(101, 159, 110, 14);
		frame.getContentPane().add(lblPickOne);
		
		diseasesField = new JTextField();
		diseasesField.setBounds(221, 156, 134, 20);
		frame.getContentPane().add(diseasesField);
		diseasesField.setColumns(10);
	}

}
