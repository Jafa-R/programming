package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Pills {

	private JFrame frame;
	private JTextField pillKindTxt;
	private JTextField howLongTxt;
	String howLong, pillKind;
	static String pillWrite;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pills window = new Pills();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pills() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("what kind of pills does tha patient medicine?");
		lblNewLabel.setBounds(87, 61, 248, 14);
		frame.getContentPane().add(lblNewLabel);
		
		pillKindTxt = new JTextField();
		pillKindTxt.setBounds(97, 86, 226, 20);
		frame.getContentPane().add(pillKindTxt);
		pillKindTxt.setColumns(10);
		
		JLabel lblHowLongHas = new JLabel("How long has he been taking this medicine?");
		lblHowLongHas.setBounds(87, 117, 248, 14);
		frame.getContentPane().add(lblHowLongHas);
		
		howLongTxt = new JTextField();
		howLongTxt.setBounds(169, 142, 86, 20);
		frame.getContentPane().add(howLongTxt);
		howLongTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StickPills.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("FINISH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pillKind = pillKindTxt.getText();
				howLong = howLongTxt.getText();
				 pillWrite = (pillKind) + (";") + (howLong);
				 String info = Pills.pillWrite;
				 try {
					 BufferedWriter File = new BufferedWriter(new FileWriter(new File("C:\\Users\\HP\\eclipse-workspace\\finalassess\\src\\finalassess\\PateintInfo.txt"), true));
					 File.write(info);
					 File.newLine();
					 File.close();
					
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
	}
}
