package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Home {

	private JFrame frame;
	private JTextField fNameTxt;
	private JTextField mNameTxt;
	private JTextField lNameTxt;
	private JTextField ageTxt;
	private JTextField insTxt;
	private JTextField idTxt;
	private JTextField genderTxt;
	private String fName, mName, lName, age, gender, ins, id;
	static String homeWrite;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblPatintFirstName = new JLabel("Patient F.Name:");
		lblPatintFirstName.setBounds(10, 50, 93, 14);
		frame.getContentPane().add(lblPatintFirstName);
		
		JLabel lblPatintMidlleName = new JLabel("Patient M.Name:");
		lblPatintMidlleName.setBounds(10, 99, 93, 14);
		frame.getContentPane().add(lblPatintMidlleName);
		
		JLabel lblPatintLastName = new JLabel("Patient L.Name:");
		lblPatintLastName.setBounds(10, 151, 93, 14);
		frame.getContentPane().add(lblPatintLastName);
		
		fNameTxt = new JTextField();
		fNameTxt.setBounds(112, 47, 86, 20);
		frame.getContentPane().add(fNameTxt);
		fNameTxt.setColumns(10);
		
		mNameTxt = new JTextField();
		mNameTxt.setColumns(10);
		mNameTxt.setBounds(112, 96, 86, 20);
		frame.getContentPane().add(mNameTxt);
		
		lNameTxt = new JTextField();
		lNameTxt.setColumns(10);
		lNameTxt.setBounds(112, 148, 86, 20);
		frame.getContentPane().add(lNameTxt);
		
		JLabel lblThePatientsAge = new JLabel("Patient's age:");
		lblThePatientsAge.setBounds(236, 50, 93, 14);
		frame.getContentPane().add(lblThePatientsAge);
		
		ageTxt = new JTextField();
		ageTxt.setBounds(341, 47, 86, 20);
		frame.getContentPane().add(ageTxt);
		ageTxt.setColumns(10);
		
		JLabel lblPatientGender = new JLabel("Patient gender:");
		lblPatientGender.setBounds(236, 99, 93, 14);
		frame.getContentPane().add(lblPatientGender);
		
		JLabel lblNewLabel = new JLabel("Insurance name:");
		lblNewLabel.setBounds(236, 151, 104, 14);
		frame.getContentPane().add(lblNewLabel);
		
		insTxt = new JTextField();
		insTxt.setBounds(341, 148, 86, 20);
		frame.getContentPane().add(insTxt);
		insTxt.setColumns(10);
		
		JLabel lblId = new JLabel("Patient ID");
		lblId.setBounds(142, 204, 56, 14);
		frame.getContentPane().add(lblId);
		
		idTxt = new JTextField();
		idTxt.setBounds(208, 201, 86, 20);
		frame.getContentPane().add(idTxt);
		idTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sur.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNext = new JButton("NEXT");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 fName = fNameTxt.getText();
				 mName = mNameTxt.getText();
				 lName = lNameTxt.getText();
				 age = ageTxt.getText();
				 gender = genderTxt.getText();
				 ins = insTxt.getText();
				 id = idTxt.getText();
				 homeWrite = (id)+(";")+(fName) + (";") + (mName) + (";") + (lName) + (";") + (age) + (";") + (gender) + (";") + (ins) + (";");
				 String info = Home.homeWrite;
				 try {
					 BufferedWriter File = new BufferedWriter(new FileWriter(new File("C:\\Users\\HP\\eclipse-workspace\\finalassess\\src\\finalassess\\PateintInfo.txt"), true));
					 File.write(info);
					 
					 File.close();
					
				} catch (IOException E) {
					// TODO: handle exception
				}
				 
				 
				
				Temp.main(null);
				frame.setVisible(false);
			}
		});
		btnNext.setBounds(328, 227, 89, 23);
		frame.getContentPane().add(btnNext);
		
		genderTxt = new JTextField();
		genderTxt.setBounds(341, 96, 86, 20);
		frame.getContentPane().add(genderTxt);
		genderTxt.setColumns(10);
	}
}
