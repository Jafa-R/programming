package finalassess;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Addiction {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addiction window = new Addiction();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Addiction() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("MOH");
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		
		JLabel lblDoesThe = new JLabel(" Does the patient has any kind of addiction? ");
		lblDoesThe.setBounds(78, 61, 258, 14);
		frame.getContentPane().add(lblDoesThe);
		
		JButton btnNewButton = new JButton("YES");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddictionType.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(165, 100, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNo = new JButton("NO");
		btnNo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StickPills.main(null);
				frame.setVisible(false);
			}
		});
		btnNo.setBounds(165, 155, 89, 23);
		frame.getContentPane().add(btnNo);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Diseases.main(null);
				frame.setVisible(false);
			}
		});
		btnBack.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
